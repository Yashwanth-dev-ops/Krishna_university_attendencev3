
import React from 'react';

// This component has been deprecated and replaced by single-page registration screens:
// - StudentRegistrationScreen.tsx
// - AdminRegistrationScreen.tsx
// This change simplifies the user flow by presenting all registration fields on one page.
const MultiStepRegistrationScreen: React.FC = () => null;

export { MultiStepRegistrationScreen };
