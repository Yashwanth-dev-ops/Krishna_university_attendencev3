// This file is a re-export to resolve a potential duplicate file issue.
// The main component is located in /components/StudentDashboard.tsx
// Fix: Correctly re-export the named 'StudentDashboard' component.
export { StudentDashboard } from './components/StudentDashboard';
