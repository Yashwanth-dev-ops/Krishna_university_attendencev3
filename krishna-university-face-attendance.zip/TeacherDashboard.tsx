// This file is a re-export to resolve a potential duplicate file issue.
// The main component is located in /components/TeacherDashboard.tsx
export * from './components/TeacherDashboard';
